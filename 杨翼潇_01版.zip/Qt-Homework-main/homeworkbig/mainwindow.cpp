#include "mainwindow.h"
#include"contants.h"
#include"screen.h"
#include"GameControlor.h"
#include"Unit.h"
#include<QGraphicsScene>
#include<QGraphicsView>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), StageId(START),
      scene(new QGraphicsScene(this)),
      view(new QGraphicsView(scene, this)),
      game(new GameControlor(*scene,this))
{
    resize(1024,768);
    Game = new GameWidget(parent);
    QPainter painter(this);
    QPixmap pix;
    QLabel *pic = new QLabel(this);
    QPropertyAnimation *animation = new QPropertyAnimation(pic, "geometry",this);
    if(!pix.load(":/pic/background.png"))
        qDebug() << "导入背景图片错误";
    pic->setPixmap(pix);
    pic->setGeometry(0,0,pix.width(), pix.height());

    animation->setDuration(3000);
    animation->setStartValue(QRect(pic->x(), pic->y(), pic->width(), pic->height()));
    animation->setEndValue(QRect(pic->x(), this->height() - pic->height(), pic->width(), pic->height()));
    animation->setEasingCurve(QEasingCurve::InOutCubic);
    animation->start();
    //setCentralWidget(view);
    setWindowTitle("开心消消乐");
    setWindowIcon(QIcon(":/pic/Gem/Gold.png"));
    len = this->width()/100*6;
    //scene->setSceneRect(-100, -100, 200, 200);
    Buttonpre();
    initSTage(StageId);
   // Start->show();
    //view->fitInView(scene->sceneRect(), Qt::KeepAspectRatioByExpanding);
}

MainWindow::~MainWindow()
{

}
void MainWindow::Buttonpre(){
    Start = new MenuButton(this->width()/10, this->width()/2, this->height()/2, this->width(), this->height(),\
                                 ":/pic/Menu/start.png", ":/pic/Menu/start_hover.png", this);
    Help = new QPushButton("帮助",this);
    Help->setFont(QFont("Algerian",18));
    Help->resize(100,50);
    Help->move(250,400);
    Start->move(250,300);
    Start->resize(100,50);
    Back = new HoverButton(this);
    One = new QPushButton("一",this);
    Two = new QPushButton("二",this);;
    restart = new QPushButton("重新开始",this);
    restart->resize(80,40);
    restart->move(100,0);
    One->setFont(QFont("Algerian",18));
    Two->setFont(QFont("Algerian",18));
    One->resize(100,50);
    Two->resize(100,50);
    One->move(200,400);
    Two->move(400,400);
    Back->setGeometry(this->width()-70, this->height()-35, 60, 30);
    Back->setFlat(true);
    Back->setImage(":/pic/Menu/exit.png", ":/pic/Menu/exit_hover.png", 60, 30);
    Help->hide();
    Start->hide();
    Back->hide();
    One->hide();
    Two->hide();
    restart->hide();

    connect(Back,&QPushButton::clicked,this,&MainWindow::Backclicked);
    connect(Help,&QPushButton::clicked,this,&MainWindow::Helpclicked);
    connect(One,&QPushButton::clicked,this,&MainWindow::Oneclicked);
    connect(Two,&QPushButton::clicked,this,&MainWindow::Twoclicked);
    connect(Start, &MenuButton::clicked,this,&MainWindow::Startclicked) ;
    connect(Game,&GameWidget::returnToMenu,this,&MainWindow::ChildFrameClose);
}
void MainWindow::initBack(int currentID){
    QPainter painter(this);
    switch (currentID) {
    case START:{

    }
        break;
    case CHOOSE:
        break;
    case HELP:
        break;
    case ONE:{
       background=QPixmap(":/pic/InGame/background.jpg");
       painter.drawPixmap(0,0,this->width(),this->height(),background);
       painter.setPen(Qt::NoPen);
       painter.setBrush(QColor(0,0,0,255));
       painter.setOpacity(0.6);
       for(int i = 0; i < 10; ++i)
           for(int j = 0; j < 10; ++j)
               if((i + j) % 2 == 0)
                   painter.drawRect(this->width()/20*7 + len*j, (this->height()- 10*len)/2 + len*i, len, len);
       painter.setOpacity(0.5);
       for(int i = 0; i < 10; ++i)
           for(int j = 0; j < 10; ++j)
               if((i + j) % 2 == 1)
                   painter.drawRect(this->width()/20*7 + len*j, (this->height()- 10*len)/2 + len*i, len, len);
       painter.setOpacity(1);
       painter.drawPixmap(this->width()/20*7, (this->height()- 10*len)/2 - len*3/8, 10*len, len*5/8, QPixmap(":/pic/InGame/top frame.png"));
    }
        break;
    case TWO:
        break;
    }
   // view->setBackgroundBrush(background);
    //view->fitInView(scene->sceneRect(), Qt::KeepAspectRatioByExpanding);
}
void MainWindow::initSTage(int currentID){
    initBack(currentID);
    switch (currentID) {
    case START:{
        Start->show();
        Help->show();
    }
        break;
    case CHOOSE:{
        Back->show();
        One->show();
        Two->show();
    }
        break;
    case HELP:
        Back->show();
        break;
    case ONE:{

        Back->show();
        restart->show();
    }
        break;
    case TWO:
        Back->show();
        restart->show();
        break;
    }
}
void MainWindow::Startclicked(){
    Start->hide();
    Help->hide();
    StageId = CHOOSE;
    initSTage(StageId);
}

void MainWindow::Backclicked(){
    scene->clear();
    Back->hide();
    One->hide();
    Two->hide();
    restart->hide();
    if(StageId==ONE||StageId == TWO)
        StageId = CHOOSE;
    else
        StageId = START;
    initSTage(StageId);
}
void MainWindow::Helpclicked(){
    Start->hide();
    Help->hide();
    StageId = HELP;
    initSTage(StageId);
}
void MainWindow::Oneclicked(){
    Game->setGeometry(this->geometry());
    this->hide();
    Game->show();


}
void MainWindow::Twoclicked(){
    Back->hide();
    One->hide();
    Two->hide();
    StageId = TWO;
    initSTage(StageId);
}
void MainWindow::ChildFrameClose(){
        this->setGeometry(Game->geometry());
        Game->is_end = true;
        Game->bgGame->stop();
        Game->hide();
        this->show();
}
