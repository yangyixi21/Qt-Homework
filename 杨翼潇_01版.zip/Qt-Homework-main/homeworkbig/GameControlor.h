#ifndef GAMECONTROLOR_H
#define GAMECONTROLOR_H

#include<QGraphicsScene>
#include<QObject>
#include<QTimer>
class pointer;
class GameControlor:public QObject
{
    Q_OBJECT
public:
    GameControlor(QGraphicsScene &scene, QObject *parent = 0);
    ~GameControlor(){}
    void start();
    void Win();
    void Fail();


public slots:
    void gameOver();
    void resume();
protected:
    bool eventFilter(QObject *object, QEvent *event);


private:
    void addNew();
    void handleKeyPressed(QKeyEvent *event);
    QTimer timer;
    QGraphicsScene &scene;



};

#endif // GAMECONTROLOR_H
