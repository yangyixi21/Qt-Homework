#include "GameWidget.h"
//#include "ui_gamewidget.h"
#include <QFileInfo>
#include <QPainter>
#include <QBrush>
#include <QRandomGenerator>
#include <QMouseEvent>
#include <QTime>
#include<QPropertyAnimation>
#include <algorithm>

GameWidget::GameWidget(QWidget *parent,int d) :
    QMainWindow(parent)
   // ui(new Ui::GameWidget)
{
   // ui->setupUi(this);
    //窗口基本设置
    setWindowFlag(Qt::Window);  //设置为独立窗口
    setWindowTitle("开心消消乐");
    setFixedSize(1024,768);
    setWindowIcon(QIcon(":/pic/Gem/Gold.png"));
    len = this->width()/100*6;

    //初始化场景、子控件及音效
    initBgm();
    initWidgets();
    initScene();

    //槽
    connect(menuButton, &QPushButton::clicked, this,&GameWidget::returnToStart);

    //connect(resetButton, &QPushButton::clicked, this, &GameWidget::reset);
}
GameWidget::~GameWidget()
{
    //delete ui;
}


void GameWidget::initBgm(){
    bgGame = new QMediaPlayer(this);

    connect(bgGame, &QMediaPlayer::mediaStatusChanged, [=](QMediaPlayer::MediaStatus status){
        if(status == QMediaPlayer::EndOfMedia && !is_end)
            bgGame->play();
    });
}
void GameWidget::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    //背景图片
    painter.drawPixmap(0,0,this->width(), this->height(), QPixmap(":/pic/InGame/background.jpg"));

    //方格
    painter.setPen(Qt::NoPen);
    painter.setBrush(QColor(0,0,0,255));
    painter.setOpacity(0.6);
    for(int i = 0; i < 9; ++i)
        for(int j = 0; j < 9; ++j)
            if((i + j) % 2 == 0)
                painter.drawRect(this->width()/20*7 + len*j, (this->height()- 10*len)/2 + len*i, len, len);
    painter.setOpacity(0.5);
    for(int i = 0; i < 9; ++i)
        for(int j = 0; j < 9; ++j)
            if((i + j) % 2 == 1)
                painter.drawRect(this->width()/20*7 + len*j, (this->height()- 10*len)/2 + len*i, len, len);


    //棋盘上下装饰
    painter.setOpacity(1);
    painter.drawPixmap(this->width()/20*7, (this->height()- 10*len)/2 - len*3/8, 9*len, len*5/8, QPixmap(":/pic/InGame/top frame.png"));
    painter.drawPixmap(this->width()/20*7, this->height() - len, 9*len, len*7/10, QPixmap(":/pic/InGame/bottom frame.png"));

    //记分器
    painter.drawPixmap(this->width()/20, this->height()/8, this->width()/5, (int)this->width() * 0.1157, QPixmap(":/pic/InGame/score.png"));

    //菜单栏
    painter.drawPixmap(this->width()/20, this->height()/20*11, this->width()/5, this->width()*14/50, QPixmap(":/pic/InGame/bottom widget classic.png"));

    QWidget::paintEvent(event);
}
void GameWidget::initWidgets(){
    menuButton = new HoverButton(this);
    resetButton = new HoverButton(this);
    scoreLabel = new QLabel("0", this);
    progressBar = new QProgressBar(this);
    decorateLabel = new QLabel(this);

    menuButton->setGeometry(this->width()/20+(int)this->width()/5 * 50.16/288, this->height()/20*11+this->width()*14/50 * 57.79/396, \
                            (int)this->width()*187.11/5/288, (int)this->width()*187.11/5/288);
    menuButton->setImage(":/pic/InGame/menu.png", ":/pic/InGame/menu_hover.png", menuButton->width(), menuButton->height());


    resetButton->setGeometry(this->width()/20 + (int)this->width()/5*93.18/288, this->height()/20*11 + this->width()*14/50*276.26/396, \
                             (int)this->width()/5*97.5/288, (int)this->width()/5*97.5/288);
    resetButton->setImage(":/pic/InGame/reset.png", ":/pic/InGame/reset_hover.png", resetButton->width(), resetButton->height());


    scoreLabel->setGeometry(this->width()/20 + (int)this->width()/5*22.68/280, this->height()/8 + (int)this->width()*0.1157*38.23/162, \
                            (int)this->width()/5*235.73/280, (int)this->width()*0.1157*57.43/162);
    scoreLabel->setFont(QFont("Microsoft YaHei", 12, 100));
    scoreLabel->setAlignment(Qt::AlignCenter);
    scoreLabel->setStyleSheet("QLabel{color:white;}");

    decorateLabel->setStyleSheet("QLabel{border-image:url(:/pic/InGame/bottom frame.png);}");
    progressBar->setGeometry(this->width()/20*7 + 20, this->height() - len, 9*len - 40, len*7/10 - 15);
    decorateLabel->setGeometry(this->width()/20*7 - 20, this->height() - len - 10, 9*len + 30, len*7/10 + 5);
    progressBar->setRange(0,99);
    progressBar->setValue(0);
    progressBar->setFormat("%p%");
    progressBar->setAlignment(Qt::AlignCenter);
    progressBar->setFont(QFont("Microsoft YaHei", 12, 100));
    progressBar->setStyleSheet("QProgressBar{color:grey;} QProgressBar::chunk{background-color:#24247e}");

    progressTimer = new QTimer(this);
    progressTimer->setInterval(1800);
    connect(progressTimer, &QTimer::timeout, [=](){
            progressBar->setValue(progressBar->value()+1);
    });

}
void GameWidget::initScene(){
    boardWidget = new QWidget(this);
    boardWidget->show();
    boardWidget->setGeometry(1024/20*7, (768- 10*len)/2, 10*len, 10*len);
    QRandomGenerator::global()->fillRange(gemBoard[0], 100);
    for(int i = 0; i < 9; ++i)
        for(int j = 0; j < 9; ++j){
            gemBoard[i][j] = gemBoard[i][j] % DIFFICULITY ;
            gems[i][j] = new Unit(gemBoard[i][j], len, i, j, boardWidget);
            gems[i][j]->installEventFilter(this);
            connect(gems[i][j],&Unit::mouseClicked,this,&GameWidget::swappre);
        }
}
void GameWidget::swappre(Unit *unit){
    if(unit->tobeswaped)
    {
        unit->tobeswaped = false;
        swapnum = 0;
    }
    else
    {
        unit->tobeswaped = true;
        swapnum++;
    }
    if(swapnum == 2)
        swap();
}
void GameWidget::swap(){
    int a=0,b=0,c=0,d=0;
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
            if(gems[i][j]->tobeswaped)
            {
                a=i;
                b=j;
                break;
            }
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
            if(gems[i][j]->tobeswaped&&gems[i][j]!=gems[a][b])
            {
                c=i;
                d=i;
            }
    if(a>c+1){
        gems[a][b]->tobeswaped = false;
        gems[c][d]->tobeswaped = false;
        swapnum = 0;
        return;
    }
    else if(a<c-1){
        gems[a][b]->tobeswaped = false;
        gems[c][d]->tobeswaped = false;
        swapnum = 0;
        return;
    }
    if(b>d+1){
        gems[a][b]->tobeswaped = false;
        gems[c][d]->tobeswaped = false;
        swapnum = 0;
        return;
    }
    else if(b<d-1){
        gems[a][b]->tobeswaped = false;
        gems[c][d]->tobeswaped = false;
        swapnum = 0;
        return;
    }
    gems[a][b]->Bomb();
    gems[c][d]->Bomb();
}
/*void GameWidget::fallAnimation(Unit *gem, int h){
    QPropertyAnimation* animation = new QPropertyAnimation(gem, "geometry", this);
    animation->setDuration(500);
    animation->setStartValue(gem->geometry());
    animation->setEndValue(QRect(gem->geometry().x(), gem->geometry().y() + len*h, gem->width(), gem->height()));
    animation->setEasingCurve(QEasingCurve::InQuad);
    animation->start();
    QTimer::singleShot(1000, this, [=](){
        delete animation;
    });
}*/
void GameWidget::start(){
    resetButton->setImage(":/pic/InGame/reset.png", ":/pic/InGame/reset_hover.png", resetButton->width(), resetButton->height());
    resetButton->setEnabled(true);
    progressBar->setValue(0);
    score = 0;
    scoreLabel->setNum(score);
    progressBar->setValue(0);
    soundGo->play();
    progressTimer->start();
}
void GameWidget::returnToStart(){
    emit returnToMenu();
    QTimer::singleShot(500, this, [=](){
        for(int i=0;i<9;i++)
            for(int j=0;j<9;j++)
                gems[i][j]->Bomb();

        delete boardWidget;
        initScene();
        this->hide();
    });
}
bool GameWidget::eventFilter(QObject *watched, QEvent *event){              //动画进行中禁用点击事件
    if(watched->metaObject()->className() == QStringLiteral("Unit"))
        if(is_acting && (event->type() == QEvent::MouseButtonPress || event->type() == QEvent::MouseButtonDblClick))
            return true;
    return QMainWindow::eventFilter(watched, event);
}


