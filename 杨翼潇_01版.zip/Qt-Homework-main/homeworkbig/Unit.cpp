#include"contants.h"
#include"Unit.h"
#include<QRandomGenerator>
#include<QPainter>

Unit::Unit(int _color, int len, int _x, int _y, QWidget *parent, int _type): QPushButton(parent),x(_x),y(_y),
    color(_color),type(_type)
{
    initGempath();


    setGeometry(len*_x, len*(_y), len, len);
    setVisible(true);
    if(type == 0){
        setStyleSheet(QString("QPushButton{border-image:url(%1);}").arg(gemPath[color]));
        setIconSize(QSize(len, len));
    }
    connect(this, &Unit::clicked, [=](bool){
        this->mouseClicked(this);
    });
}
void Unit::initGempath(){
    gemPath[0] = ":/pic/Gem/Red.png";
    gemPath[1] = ":/pic/Gem/orange.png";
    gemPath[2] = ":/pic/Gem/Green.png";
    gemPath[3] = ":/pic/Gem/Blue.png";
    gemPath[4] = ":/pic/Gem/violet.png";
    gemPath[5] = ":/pic/Gem/Silver.png";
    gemPath[6] = ":/pic/Gem/Gold.png";
}
void Unit::Bomb(){
    delete this;
}
