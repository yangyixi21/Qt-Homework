#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"GameWidget.h"
#include"MenuButton.h"
class QPushButton;
class QGraphicsScene;
class QGraphicsView;
class GameControlor;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void initSTage(int currentID);
    void initBack(int currentID);
    int StageId;
    QPixmap background;
public:
    int len;
    MenuButton *Start;
    HoverButton *Back;
    QPushButton *Help;
    QPushButton *One;
    QPushButton *Two;
    QPushButton *restart;
    GameWidget *Game;
    void Buttonpre();

private:
    QGraphicsScene *scene;
    QGraphicsView *view;
    GameControlor* game;
public slots:
    void ChildFrameClose();
    void Startclicked();
    void Backclicked();
    void Helpclicked();
    void Oneclicked();
    void Twoclicked();
};
#endif // MAINWINDOW_H
