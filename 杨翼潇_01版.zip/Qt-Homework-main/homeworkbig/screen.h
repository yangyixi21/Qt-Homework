#ifndef SCREEN_H
#define SCREEN_H
#include<QMainWindow>
#include<QObject>
#include<QEvent>
#include<QPushButton>
#include<QLabel>
#include<vector>
class QGraphicsScene;
class Screen:public QObject
{
    Q_OBJECT
public:
    std::vector<QPushButton> buttonvec;
    int stageId;
    int currentstage;
    QPixmap background;
    Screen(QGraphicsScene &scene, QObject *parent = 0);

protected:
    void advance(int ID);
private:
    void ButtonShow(int ID);
    QGraphicsScene &Scene;
    void initStage(int ID);

};


#endif // SCREEN_H
