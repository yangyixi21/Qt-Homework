#ifndef UNIT_H
#define UNIT_H

#include <QWidget>
#include <QMap>
#include <QPushButton>
#include <QPixmap>
#include <QMovie>
#include <QLabel>

class Unit:public QPushButton
{
    Q_OBJECT
public:
    Unit(int _color, int len, int _x, int _y, QWidget *parent = nullptr, int _type=0);
    void initGempath();
       void Bomb();
    bool tobeswaped = false;
    void setY(int n){y=n;}
    void setType(int n){type = n;}
    int ux(){return x;}
    int uy(){return y;}
    int ucolor(){return color;}
    int utype(){return type;}

private:
    QMap<int, QString> gemPath;
    int x,y;
    int color;
    int type;
signals:
    void mouseClicked(Unit*);
};

#endif // UNIT_H
