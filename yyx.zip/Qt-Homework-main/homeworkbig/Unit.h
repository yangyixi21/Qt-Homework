#ifndef UNIT_H
#define UNIT_H

#include<QGraphicsItem>

class Unit:public QGraphicsItem
{
public:
    Unit(qreal x,qreal y);

    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *);

    QPainterPath shape() const;
};

#endif // UNIT_H
