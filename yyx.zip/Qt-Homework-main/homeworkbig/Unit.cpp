#include"contants.h"
#include"Unit.h"
#include<QRandomGenerator>
#include<QPainter>
static const qreal FOOD_RADIUS = 3;
Unit::Unit(qreal x,qreal y){
    setPos(x,y);
    setData(GD_Type,Normal);
    int color = QRandomGenerator::global()->bounded(0,5);
    switch (color) {
    case GC_Red:
        setData(GD_Color,GC_Red);
        break;
    case GC_Blue:
        setData(GD_Color,GC_Blue);
        break;
    case GC_Green:
        setData(GD_Color,GC_Green);
        break;
    case GC_Purple:
        setData(GD_Color,GC_Purple);
        break;
    case GC_Yellow:
        setData(GD_Color,GC_Yellow);
        break;
    }
}
QRectF Unit::boundingRect() const
{
    return QRectF(-S_SIZE,    -S_SIZE,
                  S_SIZE * 2, S_SIZE * 2 );
}
void Unit::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->save();

    painter->setRenderHint(QPainter::Antialiasing);
    if(data(GD_Color)==GC_Red)
        painter->fillPath(shape(), Qt::red);
    else if(data(GD_Color) == GC_Blue)
        painter->fillPath(shape(),Qt::blue);
    else if(data(GD_Color) == GC_Green)
        painter->fillPath(shape(),Qt::green);
    else if (data(GD_Color) == GC_Yellow)
        painter->fillPath(shape(),Qt::yellow);
    else
        painter->fillPath(shape(),Qt::black);

    painter->restore();
}
QPainterPath Unit::shape() const{
    QPainterPath p;
    p.addEllipse(QPointF(S_SIZE / 2, S_SIZE / 2), FOOD_RADIUS, FOOD_RADIUS);
    return p;
}
