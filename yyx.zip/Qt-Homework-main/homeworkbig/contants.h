#ifndef CONTANTS_H
#define CONTANTS_H
const int S_SIZE = 10;
enum STAGE{
    START=1000,
    CHOOSE,
    HELP,
    FAIL,
    WIN,
    ONE,
    TWO
};
enum GameData{
    GD_Type,
    GD_Color
};
enum Game_Type{
    Normal,
    X,
    Y,
    Exploded,
    Magic
};
enum Game_Coloe{
    GC_Red=0,
    GC_Yellow,
    GC_Blue,
    GC_Green,
    GC_Purple
};

#endif // CONTANTS_H
