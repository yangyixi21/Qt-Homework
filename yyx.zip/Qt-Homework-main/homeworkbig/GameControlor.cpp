#include"GameControlor.h"
#include"contants.h"
#include"Unit.h"
#include"pointer.h"
#include <QEvent>
#include<QRandomGenerator>
#include <QKeyEvent>
GameControlor::GameControlor(QGraphicsScene &scene, QObject *parent) :
    QObject(parent),Pointer(new pointer(*this)),
    scene(scene){
    timer.start( 1000/33 );
    scene.installEventFilter(this);
    resume();
}
void GameControlor::start(){
    scene.addItem(Pointer);
    Unit* a = new Unit(0,50);
    scene.addItem(a);
}
void GameControlor::Win(){

}
void GameControlor::Fail(){

}
void GameControlor::handleKeyPressed(QKeyEvent *event){
    switch (event->key()) {
        case Qt::Key_Left:
            Pointer->moveLeft();
            break;
        case Qt::Key_Right:
            Pointer->moveRight();
            break;
        case Qt::Key_Up:
            Pointer->moveUp();
            break;
        case Qt::Key_Down:
            Pointer->moveDown();
            break;
        case Qt::Key_W:
        scene.clear();
            break;

    }
}
void GameControlor::addNew(){

}
void GameControlor::resume(){
    connect(&timer, SIGNAL(timeout()),
            &scene, SLOT(advance()));
}
void GameControlor::gameOver(){

}
bool GameControlor::eventFilter(QObject *object, QEvent *event)
{
    if (event->type() == QEvent::KeyPress) {
        handleKeyPressed((QKeyEvent *)event);
        return true;
    } else {
        return QObject::eventFilter(object, event);
    }
}
