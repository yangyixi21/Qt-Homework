#include"contants.h"
#include"pointer.h"
#include"GameControlor.h"
#include<QPainter>
pointer::pointer(GameControlor & controlor,qreal x,qreal y):px(x),py(y),controller(controlor){

}
QRectF pointer::boundingRect() const{
    return QRectF(-S_SIZE/2,-S_SIZE/2,S_SIZE/2,S_SIZE/2);
}
QPainterPath pointer::shape() const{
    QPainterPath p;
    p.addEllipse(QPointF(S_SIZE / 2, S_SIZE / 2),1,1);
    return p;
}
void pointer::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *){
    painter->save();
    painter->fillPath(shape(), Qt::white);
    painter->restore();
}
void pointer::advance(){

    setPos(px,py);
}
void pointer::moveRight(){
    px -= 30;
    if(px<=-100)
        px=100;
}
void pointer::moveLeft(){
    px+=30;
    if(px>=100)
        px=-100;
}
void pointer::moveUp(){
    py-=30;
    if(py<=-100)
        py=100;
}
void pointer::moveDown(){
    py+=30;
    if(py>=100)
        py=-100;
}
