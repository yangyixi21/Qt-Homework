#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
class QPushButton;
class QGraphicsScene;
class QGraphicsView;
class GameControlor;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void initSTage(int currentID);
    void initBack(int currentID);
    int StageId;
    QPixmap background;
public:
    QPushButton *Start;
    QPushButton *Back;
    QPushButton *Help;
    QPushButton *One;
    QPushButton *Two;
    QPushButton *restart;
    void Buttonpre();

private:
    QGraphicsScene *scene;
    QGraphicsView *view;
    GameControlor* game;
public slots:
    void Startclicked();
    void Backclicked();
    void Helpclicked();
    void Oneclicked();
    void Twoclicked();
};
#endif // MAINWINDOW_H
