#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QMainWindow>
#include <QMediaPlayer>
#include "Hoverbutton.h"
#include <QLabel>
#include <QProgressBar>
#include"Unit.h"
#include <QPropertyAnimation>
#include <QTimer>
#include <QSoundEffect>
#include <vector>
#include <QEvent>
#include <vector>

namespace Ui {
class GameWidget;
}

class GameWidget : public QMainWindow
{
    Q_OBJECT

public:
    explicit GameWidget(QWidget *parent = nullptr,int d=1);
    ~GameWidget();
    //背景音乐
    QMediaPlayer* bgGame;
        QString userName="";
    bool is_end= false;             //背景音乐循环是否停止
    void start();
    int a=0,b=0,c=0,d=0;
    void setDifficulity(int d);

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    int DIFFICULITY = 7;          //宝石种类数
   // Ui::GameWidget *ui;
    HoverButton* menuButton, *resetButton;
    QLabel* scoreLabel, *decorateLabel;
    QProgressBar* progressBar;
    QWidget* boardWidget;
    int len;
    QTimer *progressTimer;
    int score=0;
    int swapnum = 0;
    int bombnum = 0;
    unsigned int gemBoard[9][9];          //第一个值为x，第二个值为y
    int fallBoard[9][9];
    Unit* gems[9][9];
    QSoundEffect* soundGo, *soundGood, *soundExcellent, *soundAwesome, *soundBadmove, *soundAct, *soundFall, *soundGenerate,\
                                    *soundUnbelievable, *soundTimeUp, *soundNoMoreMoves, *soundMagic;
    bool is_acting=false;
    std::vector<Unit*> toBomb;
    void paintEvent(QPaintEvent *event) override;
    void initWidgets();
    void initScene();
    void initBgm();
    void returnToStart();
    void swappre(Unit *unit);
    void swap();
    void Unitswap(int i,int j,int m,int n);

    int getx(int i,int j);
    int gety(int i, int j);
    int getRight(int i,int j);
    int getLeft(int i,int j);
    int getUp(int i,int j);
    int  getDown(int i,int j);

    void setBomb(int i,int j);
    void center(int i,int j);
    void BombUnit();
    void fall();
    void fallAnimation(Unit* target, int h);
    void fillBoard();

   /* bool isFail();

    void end();
    int randomGem(bool allowMagic=true);
    void sort();

    void showMenu();
    void returnToStart();
    void reset();*/

signals:
    void returnToMenu();

};

#endif // GAMEWIDGET_H
