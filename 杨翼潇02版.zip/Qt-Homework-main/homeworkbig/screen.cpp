#include"screen.h"
#include"contants.h"
#include<QGraphicsScene>
#include<QPainter>
#include<QBrush>
Screen::Screen(QGraphicsScene &scene, QObject *parent):
    stageId(START),currentstage(START),Scene(scene)
{
    initStage(currentstage);
}

void Screen::initStage(int ID){
    switch (ID) {
    case START:{
        QPixmap bg(10,10);
        background=bg;
        QPainter p(&background);
        p.setBrush(QBrush(Qt::gray));
        p.drawRect(0, 0, 10,10);

        }
        break;
    case CHOOSE:
        break;

    }
    ButtonShow(ID);
}
void Screen::ButtonShow(int ID){
    switch (ID) {
    case START:{

    }
        break;

    }
}
