#ifndef POINTER_H
#define POINTER_H

#include<QGraphicsItem>
class GameControlor;
class pointer:public QGraphicsItem{
public:
    enum Direction {
        MoveLeft,
        MoveRight,
        MoveUp,
        MoveDown
    };
    pointer(GameControlor & controlor,qreal x=0,qreal y=0);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *);
    QRectF boundingRect() const;
    QPainterPath shape() const;
    qreal px,py;

protected:
    void advance();
public:
    GameControlor &controller;
    void moveLeft();
    void moveRight();
    void moveUp();
    void moveDown();
};

#endif // POINTER_H
