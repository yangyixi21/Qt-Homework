#include "GameWidget.h"
//#include "ui_gamewidget.h"
#include <QFileInfo>
#include <QPainter>
#include <QBrush>
#include <QRandomGenerator>
#include <QMouseEvent>
#include <QTime>
#include<QPropertyAnimation>
#include <algorithm>

GameWidget::GameWidget(QWidget *parent,int d) :
    QMainWindow(parent)
   // ui(new Ui::GameWidget)
{
   // ui->setupUi(this);
    //窗口基本设置
    setWindowFlag(Qt::Window);  //设置为独立窗口
    setWindowTitle("开心消消乐");
    setFixedSize(1024,768);
    setWindowIcon(QIcon(":/pic/Gem/Gold.png"));
    len = this->width()/100*6;

    //初始化场景、子控件及音效
    initBgm();
    initWidgets();
    initScene();

    //槽
    connect(menuButton, &QPushButton::clicked, this,&GameWidget::returnToStart);

    //connect(resetButton, &QPushButton::clicked, this, &GameWidget::reset);
}
GameWidget::~GameWidget()
{
    //delete ui;
}


void GameWidget::initBgm(){
    bgGame = new QMediaPlayer(this);

    connect(bgGame, &QMediaPlayer::mediaStatusChanged, [=](QMediaPlayer::MediaStatus status){
        if(status == QMediaPlayer::EndOfMedia && !is_end)
            bgGame->play();
    });
}
void GameWidget::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    //背景图片
    painter.drawPixmap(0,0,this->width(), this->height(), QPixmap(":/pic/InGame/background.jpg"));

    //方格
    painter.setPen(Qt::NoPen);
    painter.setBrush(QColor(0,0,0,255));
    painter.setOpacity(0.6);
    for(int i = 0; i < 9; ++i)
        for(int j = 0; j < 9; ++j)
            if((i + j) % 2 == 0)
                painter.drawRect(this->width()/20*7 + len*j, (this->height()- 10*len)/2 + len*i, len, len);
    painter.setOpacity(0.5);
    for(int i = 0; i < 9; ++i)
        for(int j = 0; j < 9; ++j)
            if((i + j) % 2 == 1)
                painter.drawRect(this->width()/20*7 + len*j, (this->height()- 10*len)/2 + len*i, len, len);


    //棋盘上下装饰
    painter.setOpacity(1);
    painter.drawPixmap(this->width()/20*7, (this->height()- 10*len)/2 - len*3/8, 9*len, len*5/8, QPixmap(":/pic/InGame/top frame.png"));
    painter.drawPixmap(this->width()/20*7, this->height() - len, 9*len, len*7/10, QPixmap(":/pic/InGame/bottom frame.png"));

    //记分器
    painter.drawPixmap(this->width()/20, this->height()/8, this->width()/5, (int)this->width() * 0.1157, QPixmap(":/pic/InGame/score.png"));

    //菜单栏
    painter.drawPixmap(this->width()/20, this->height()/20*11, this->width()/5, this->width()*14/50, QPixmap(":/pic/InGame/bottom widget classic.png"));

    QWidget::paintEvent(event);
}
void GameWidget::initWidgets(){
    menuButton = new HoverButton(this);
    resetButton = new HoverButton(this);
    scoreLabel = new QLabel("0", this);
    progressBar = new QProgressBar(this);
    decorateLabel = new QLabel(this);

    menuButton->setGeometry(this->width()/20+(int)this->width()/5 * 50.16/288, this->height()/20*11+this->width()*14/50 * 57.79/396, \
                            (int)this->width()*187.11/5/288, (int)this->width()*187.11/5/288);
    menuButton->setImage(":/pic/InGame/menu.png", ":/pic/InGame/menu_hover.png", menuButton->width(), menuButton->height());


    resetButton->setGeometry(this->width()/20 + (int)this->width()/5*93.18/288, this->height()/20*11 + this->width()*14/50*276.26/396, \
                             (int)this->width()/5*97.5/288, (int)this->width()/5*97.5/288);
    resetButton->setImage(":/pic/InGame/reset.png", ":/pic/InGame/reset_hover.png", resetButton->width(), resetButton->height());


    scoreLabel->setGeometry(this->width()/20 + (int)this->width()/5*22.68/280, this->height()/8 + (int)this->width()*0.1157*38.23/162, \
                            (int)this->width()/5*235.73/280, (int)this->width()*0.1157*57.43/162);
    scoreLabel->setFont(QFont("Microsoft YaHei", 12, 100));
    scoreLabel->setAlignment(Qt::AlignCenter);
    scoreLabel->setStyleSheet("QLabel{color:white;}");

    decorateLabel->setStyleSheet("QLabel{border-image:url(:/pic/InGame/bottom frame.png);}");
    progressBar->setGeometry(this->width()/20*7 + 20, this->height() - len, 9*len - 40, len*7/10 - 15);
    decorateLabel->setGeometry(this->width()/20*7 - 20, this->height() - len - 10, 9*len + 30, len*7/10 + 5);
    progressBar->setRange(0,99);
    progressBar->setValue(0);
    progressBar->setFormat("%p%");
    progressBar->setAlignment(Qt::AlignCenter);
    progressBar->setFont(QFont("Microsoft YaHei", 12, 100));
    progressBar->setStyleSheet("QProgressBar{color:grey;} QProgressBar::chunk{background-color:#24247e}");

    progressTimer = new QTimer(this);
    progressTimer->setInterval(1800);
   /* connect(progressTimer, &QTimer::timeout, [=](){
            progressBar->setValue(progressBar->value()+1);
    });*/

}
void GameWidget::initScene(){
    boardWidget = new QWidget(this);
    boardWidget->show();
    boardWidget->setGeometry(1024/20*7, (768- 10*len)/2, 10*len, 10*len);
    QRandomGenerator::global()->fillRange(gemBoard[0], 100);
    for(int i = 0; i < 9; ++i)
        for(int j = 0; j < 9; ++j){
            gemBoard[i][j] = gemBoard[i][j] % DIFFICULITY ;
            if(i>=2&&j>=2){
                if((gemBoard[i-1][j]==gemBoard[i-2][j])&&(gemBoard[i][j-1]==gemBoard[i][j-2]))
                {
                    while(gemBoard[i][j]==gemBoard[i][j-1]||gemBoard[i][j]==gemBoard[i-1][j])
                    {
                        gemBoard[i][j] = QRandomGenerator::global()->bounded(0,7);
                    }
                }
                else if(gemBoard[i-1][j]==gemBoard[i-2][j])
                {
                    while(gemBoard[i-1][j]==gemBoard[i][j]){
                        gemBoard[i][j] = QRandomGenerator::global()->bounded(0,7);
                    }
                }
                else if(gemBoard[i][j-1]==gemBoard[i][j-2]){
                    while(gemBoard[i][j-1]==gemBoard[i][j])
                    {
                         gemBoard[i][j] = QRandomGenerator::global()->bounded(0,7);
                    }
                }
            }
            else if(i>=2){
                if(gemBoard[i-1][j]==gemBoard[i-2][j])
                                {
                                    while(gemBoard[i-1][j]==gemBoard[i][j]){
                                        gemBoard[i][j] = QRandomGenerator::global()->bounded(0,7);
                                    }
                                }
            }
            else if(j>=2){
                if(gemBoard[i][j-1]==gemBoard[i][j-2]){
                                    while(gemBoard[i][j-1]==gemBoard[i][j])
                                    {
                                         gemBoard[i][j] = QRandomGenerator::global()->bounded(0,7);
                                    }
                                }
            }
            gems[i][j] = new Unit(gemBoard[i][j], len, i, j, boardWidget);
            gems[i][j]->installEventFilter(this);
            connect(gems[i][j],&Unit::mouseClicked,this,&GameWidget::swappre);
        }
}
void GameWidget::swappre(Unit *unit){
    if(unit->tobeswaped)
    {
        unit->setswap(false);
        swapnum = 0;
    }
    else
    {
        unit->setswap(true);;
        swapnum++;
        if(swapnum == 1)
        {
            a = unit->ux();
            b= unit->uy();
        }
        else{
            c=unit->ux();
            d = unit->uy();
        }
    }
    if(swapnum == 2)
        swap();
}
void GameWidget::swap(){
    if(a>c+1){
        gems[a][b]->setswap(false);
        gems[c][d]->setswap(false);
        swapnum = 0;
        return;
    }
    else if(a<c-1){
        gems[a][b]->setswap(false);
        gems[c][d]->setswap(false);
        swapnum = 0;
        return;
    }
    if(b>d+1){
        gems[a][b]->setswap(false);
        gems[c][d]->setswap(false);
        swapnum = 0;
        return;
    }
    else if(b<d-1){
        gems[a][b]->setswap(false);
        gems[c][d]->setswap(false);
        swapnum = 0;
        return;
    }
    Unitswap(a,b,c,d);
    if(getx(a,b)<3&&gety(a,b)<3&&getx(c,d)<3&&gety(c,d)<3){
        Unitswap(a,b,c,d);
        swapnum = 0;
        return;
    }
    else{
        is_acting = true;
        center(a,b);
        center(c,d);
        swapnum = 0;
        BombUnit();
        is_acting = false;
    }

}
void GameWidget::BombUnit(){

    if(bombnum == 0)
        return;
    for(int i = 0; i < 9; ++i)
        for(int j = 0; j < 9; ++j)
            fallBoard[i][j]=0;

    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
        if(gems[i][j]->toBomb){
            gemBoard[i][j]=100;
            fallBoard[i][j] = -1;
            for(int k = j-1;k>=0;k--)
            if(fallBoard[i][k]!=-1){
                fallBoard[i][k]++;
            }
        }
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
            if(fallBoard[i][j] == -1){
                gems[i][j]->Bomb();
                bombnum--;
            }
    fall();
    fillBoard();
}
void GameWidget::fall(){
    for(int i = 0; i < 9; ++i)
        for(int j = 8; j >= 0; --j){
            if(fallBoard[i][j] != -1 && fallBoard[i][j] != 0 && gemBoard[i][j] != 100){
                gemBoard[i][j + fallBoard[i][j]] = gemBoard[i][j];
                gems[i][j]->setY(gems[i][j]->uy() + fallBoard[i][j]);
                gems[i][j + fallBoard[i][j]] = gems[i][j];
                gemBoard[i][j] = 100;
                fallAnimation(gems[i][j], fallBoard[i][j]);
            }
        }
}

void GameWidget::fillBoard(){
    int lack[9] = {0};
    for(int i = 0;i<9;i++)
        for(int j=0;j<9;j++){
            if(fallBoard[i][j] == -1)
                lack[i]++;
            else if(fallBoard[i][j]!=0){
                lack[i] += fallBoard[i][j];
                break;
            }
        }
    for(int i=0;i<9;i++)
        for(int j=0;j<lack[i];j++){
            gemBoard[i][lack[i]-j-1] = QRandomGenerator::global()->bounded(0,7);
            gems[i][lack[i]-j-1] = new Unit(gemBoard[i][lack[i]-j-1],len,i,-j-1,boardWidget);
            gems[i][lack[i]-j-1]->setY(lack[i]-j-1);
            gems[i][lack[i]-j-1] -> installEventFilter(this);
            connect(gems[i][lack[i]-j-1], &Unit::mouseClicked, this,&GameWidget::swappre);
        }
    for(int i = 0; i < 9; i++)
        for(int j = 0; j < lack[i]; ++j){
            fallAnimation(gems[i][lack[i]-j-1], lack[i]);
        }
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
            if(fallBoard[i][j]!=0&&!gems[i][j]->toBomb){
                if(getx(i,j)<3&&gety(i,j)<3)
                    continue;
                if(getx(i,j) == 5)
                    center(i+2,j);
                else if(gety(i,j) == 5)
                    center(i,j+2);
                else if(getx(i,j) >=3){
                    for(int k=i;k<i+getx(i,j);k++)
                        if(gety(k,j)>=3){
                        center(k,j);
                        break;
                    }
                    if(!gems[i][j]->toBomb)
                        center(i,j);
                }
                else if(gety(i,j) >=3){
                    for(int k=j;k<j+gety(i,j);k++){
                        if(getx(k,j) == 4){
                            center(k,j);
                            break;
                        }
                    }
                    if(!gems[i][j]->toBomb)
                        center(i,j);
                }
            }
    if(bombnum!=0)
        QTimer::singleShot(1000,this,[=](){
            BombUnit();
        });
}
void GameWidget::center(int i, int j){
    if(getx(i,j)<3&&gety(i,j)<3)
        return;
    if(getx(i,j) == 3&&gety(i,j)<3){
        for(int m= i-getLeft(i,j);m<=i+getRight(i,j);m++)
        {
            setBomb(m,j);
            bombnum++;
        }
        return;
    }
    else if(gety(i,j) == 3&&getx(i,j)<3){
        for(int m = j-getUp(i,j);m<=j+getDown(i,j);m++)
        {
            setBomb(i,m);
            bombnum++;
        }
        return;
    }
    else if(getx(i,j) == 5){
        for(int m = i-2;m<=i+2;m++)
            if(m!=i){
                setBomb(m,j);
                bombnum++;
            }
        //gems[i][j]->setType(5);
        if(gety(i,j)>=3)
            for(int m = j-getUp(i,j);m<=j+getDown(i,j);m++)
            {
                setBomb(i,m);
                bombnum++;
            }
        return;
    }
    else if(gety(i,j) == 5){
        for(int m = j-2;m<=j+2;m++)
            if(m!=j){
                setBomb(i,m);
                bombnum++;
            }
        //gems[i][j]->setType(4);
        if(getx(i,j)>=3)
            for(int m = j-getLeft(i,j);m<=j+getRight(i,j);m++)
            if(m!=j){
                setBomb(i,m);
                bombnum++;
            }
        return;
    }
    else if(getx(i,j)>=3&&gety(i,j)>=3){
        for(int m = i-getLeft(i,j);m<=i+getRight(i,j);m++)
            if(m!=i){
                setBomb(m,j);
                bombnum++;
            }
        //gems[i][j]->setType(3);
        for(int m = j-getUp(i,j);m<=i+getDown(i,j);m++)
            if(m!=j){
                setBomb(i,m);
                bombnum++;
            }
        return;
    }
    else if(getx(i,j) == 4){
        //gems[i][j]->setType(2);
        for(int m = i-getLeft(i,j);m<=i+getRight(i,j);m++)
            if(m!=i){
                setBomb(m,j);
                bombnum++;
            }
        return;
    }
    else if(gety(i,j)==4){
        //gems[i][j]->setType(1);
        for(int m = j-getUp(i,j);m<=i+getDown(i,j);m++)
            if(m!=j){
                setBomb(i,m);
                bombnum++;
            }
        return;
    }
}
void GameWidget::setBomb(int i, int j){
    if(gems[i][j]->utype() == 0)
        gems[i][j]->toBomb = true;
}
void GameWidget::Unitswap(int i, int j, int m, int n){
    int color = gems[i][j]->ucolor();
    int type = gems[i][j]->utype();
    gems[i][j]->Bomb();
    gems[i][j] = new Unit(gems[m][n]->ucolor(),len,i,j,boardWidget,gems[m][n]->utype());
    gems[m][n]->Bomb();
    gems[m][n] = new Unit(color,len,m,n,boardWidget,type);
    connect(gems[i][j],&Unit::mouseClicked,this,&GameWidget::swappre);
    connect(gems[m][n],&Unit::mouseClicked,this,&GameWidget::swappre);
}
int GameWidget::getx(int i, int j){
    return getRight(i,j)+getLeft(i,j)+1;
}
int GameWidget::getRight(int i, int j){
    int num =0;
    for(int m = i+1;m<9;m++)
    {
        if(gems[m][j]->ucolor() == gems[i][j]->ucolor())
            num++;
        else
            break;
    }
    return num;
}
int GameWidget::getLeft(int i, int j){
    int num =0;
    for(int m = i-1;m>=0;m--)
    {
        if(gems[m][j]->ucolor() == gems[i][j]->ucolor())
            num++;
        else
            break;
    }
    return num;
}
int GameWidget::gety(int i, int j){
    return getDown(i,j)+getUp(i,j)+1;
}
int GameWidget::getDown(int i, int j){
    int num=0;
    for(int m=j+1;m<9;m++)
    {
        if(gems[i][m]->ucolor() == gems[i][j]->ucolor())
            num++;
        else
            break;
    }
    return num;
}
int GameWidget::getUp(int i, int j){
    int num = 0;
    for(int m=j-1;m>=0;m--)
    {
        if(gems[i][m]->ucolor() == gems[i][j]->ucolor())
            num++;
        else
            break;
    }
    return num;
}
void GameWidget::fallAnimation(Unit *gem, int h){
    QPropertyAnimation* animation = new QPropertyAnimation(gem, "geometry", this);
    animation->setDuration(500);
    animation->setStartValue(gem->geometry());
    animation->setEndValue(QRect(gem->geometry().x(), gem->geometry().y() + len*h, gem->width(), gem->height()));
    animation->setEasingCurve(QEasingCurve::InQuad);
    animation->start();
    QTimer::singleShot(1000, this, [=](){
        delete animation;
    });
}
void GameWidget::start(){
    resetButton->setImage(":/pic/InGame/reset.png", ":/pic/InGame/reset_hover.png", resetButton->width(), resetButton->height());
    resetButton->setEnabled(true);
    progressBar->setValue(0);
    score = 0;
    scoreLabel->setNum(score);
    progressBar->setValue(0);
    soundGo->play();
    //progressTimer->start();
}
void GameWidget::returnToStart(){
    emit returnToMenu();
    QTimer::singleShot(500, this, [=](){
        for(int i=0;i<9;i++)
            for(int j=0;j<9;j++)
                gems[i][j]->Bomb();

        delete boardWidget;
        initScene();
        this->hide();
    });
}
bool GameWidget::eventFilter(QObject *watched, QEvent *event){              //动画进行中禁用点击事件
    if(watched->metaObject()->className() == QStringLiteral("Unit"))
        if(is_acting && (event->type() == QEvent::MouseButtonPress || event->type() == QEvent::MouseButtonDblClick))
            return true;
    return QMainWindow::eventFilter(watched, event);
}


