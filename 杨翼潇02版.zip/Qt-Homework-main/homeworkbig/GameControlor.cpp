#include"GameControlor.h"
#include"contants.h"
#include"Unit.h"
#include"pointer.h"
#include <QEvent>
#include<QRandomGenerator>
#include <QKeyEvent>
GameControlor::GameControlor(QGraphicsScene &scene, QObject *parent) :
    QObject(parent),
    scene(scene){
    timer.start( 1000/33 );
    scene.installEventFilter(this);
    resume();
}
void GameControlor::start(){

}
void GameControlor::Win(){

}
void GameControlor::Fail(){

}
void GameControlor::handleKeyPressed(QKeyEvent *event){

}
void GameControlor::addNew(){

}
void GameControlor::resume(){
    connect(&timer, SIGNAL(timeout()),
            &scene, SLOT(advance()));
}
void GameControlor::gameOver(){

}
bool GameControlor::eventFilter(QObject *object, QEvent *event)
{
    if (event->type() == QEvent::KeyPress) {
        handleKeyPressed((QKeyEvent *)event);
        return true;
    } else {
        return QObject::eventFilter(object, event);
    }
}
