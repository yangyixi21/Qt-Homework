#include "mainwindow.h"
#include"GameWidget.h"
#include <QApplication>
#include<QPainter>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //GameWidget w;
    MainWindow w;
  //  painter.drawPixmap(this->width()/20*7, (this->height()- 10*len)/2 - len*3/8, 10*len, len*5/8, QPixmap(":/pic/InGame/top frame.png"));
    w.show();
    return a.exec();
}
